package API_Objects;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.JsonNode;

public class PromotionsResponseObject   {

    @JsonProperty("id")
    private JsonNode id;

    @JsonProperty("title")
    private JsonNode title;

    @JsonProperty("cta_label")
    private JsonNode cta_label;

    @JsonProperty("image_url")
    private JsonNode image_url;

    @JsonProperty("foreground_url")
    private JsonNode foreground_url;

    @JsonProperty("description")
    private JsonNode description;

    @JsonProperty("promotion_target")
    private JsonNode promotion_target;

    @JsonProperty("analytics_key")
    private JsonNode analytics_key;

    @JsonProperty("cobrand_tile")
    private JsonNode cobrand_tile;

    @JsonProperty("send_to_bank")
    private JsonNode send_to_bank;

    @JsonProperty("navigation_style")
    private JsonNode navigation_style;

    @JsonProperty("target_destination")
    private JsonNode target_destination;

    @JsonProperty("sort_order")
    private JsonNode sort_order;


    public JsonNode getId() {
        return id;
    }

    public JsonNode getTitle() {
        return title;
    }

    public JsonNode getCta_label() {
        return cta_label;
    }

    public JsonNode getImage_url() {
        return image_url;
    }

    public JsonNode getForeground_url() {
        return foreground_url;
    }

    public JsonNode getDescription() {
        return description;
    }

    public JsonNode getPromotion_target() {
        return promotion_target;
    }

    public JsonNode getAnalytics_key() {
        return analytics_key;
    }

    public JsonNode getCobrand_tile() {
        return cobrand_tile;
    }

    public JsonNode getSend_to_bank() {
        return send_to_bank;
    }

    public JsonNode getNavigation_style() {
        return navigation_style;
    }

    public JsonNode getTarget_destination() {
        return target_destination;
    }

    public JsonNode getSort_order() {
        return sort_order;
    }
}
