package API_Objects;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.JsonNode;

public class LoginResponseObject {


    @JsonProperty("access_token")
    private JsonNode accessToken;

    @JsonProperty("scope")
    private JsonNode scope;

    @JsonProperty("expires_in")
    private JsonNode expires_in;

    @JsonProperty("token_type")
    private JsonNode token_type;


    public JsonNode getAccessToken() {
        return accessToken;
    }
}
