package Apis;

import Common.PostHelper;
import Constants.Constants;
import io.restassured.response.Response;
import org.json.JSONObject;

public class LoginAPI {
    static Response loginResponse;

    public static Response postLogin(String username,String password) {
        JSONObject jsonObj=new JSONObject("{\"grant_type\":\"password\",\n" +
                "\"username\":\""+username+"\",\n" +
                "\"password\":\""+password+"\",\n" +
                "\"audience\":\"https://sit.maf-dev.auth0.com/api/v2/\",\n" +
                "\"client_id\":\"l9DGyNKhON48e6BgTFAg17wWY78urJ4t\",\n" +
                "\"client_secret\":\"yl9xlvv9N35GpLYDxBp22HLFvPv4_RrtPQxFhznSV2C5xqUYWVWqXl7qwdt2gq2f\"}");
       loginResponse= PostHelper.post(Constants.LOGIN_PATH,jsonObj);
        return loginResponse;
    }
}
