package Common;

import java.util.HashMap;
import java.util.Map;

public class Headers {

    public static Map<String, String> requestHeader() {
        Map<String, String> header = new HashMap<String, String>();
        header.put("content-type", "application/json");

        return header;

    }
    public static Map<String, String> requestHeaderWith_X_API_KEYandToken(String token) {
        Map<String, String> header = new HashMap<String, String>();
        header.put("content-type", "application/json");
        header.put("x-api-key", "GfqP7b2I99sUMkbxGEk5Xk56RscaWRuo");
        header.put("Authorization","bearer "+token);


        return header;

    }
}
