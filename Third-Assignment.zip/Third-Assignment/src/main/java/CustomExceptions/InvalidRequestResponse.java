package CustomExceptions;

public class InvalidRequestResponse extends Throwable {
    public InvalidRequestResponse(String s) {
    }
}
