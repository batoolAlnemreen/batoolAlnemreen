package Constants;

public class Constants {
    public static String LOGIN_PATH;
    public static String BASE_URL;
    public static String PROMOTIONS_PATH;
    public static String DEV_URL;


    static {
        BASE_URL="https://sit.maf-dev.auth0.com";
        DEV_URL= "https://maf-holding-dev.apigee.net";
        LOGIN_PATH= BASE_URL+"/oauth/token";
        PROMOTIONS_PATH=DEV_URL+"/v1/share/promote-sections/3";
    }

        }
