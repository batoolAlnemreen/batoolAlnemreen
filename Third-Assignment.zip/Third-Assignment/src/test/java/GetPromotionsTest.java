import API_Objects.LoginResponseObject;
import API_Objects.PromotionsResponseObject;
import Apis.GetPromotionsAPI;
import Apis.LoginAPI;
import Common.Helper;
import Mapper.LoginMapper;
import Mapper.PromotionsMapper;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;

public class GetPromotionsTest {

    @Test(description = "Validate JSON Schema and data types")
    public void testPromotionsAPI(){
        GetPromotionsAPI promotion=new GetPromotionsAPI();
        LoginTest loginTest=new LoginTest();
        loginTest.testLogin();
        Response response= promotion.getPromotions(loginTest.accessToken);
        response.prettyPrint();
        PromotionsResponseObject promotionsResponseObject= PromotionsMapper.readPromotionsObject(response);
        Helper.validateJSONSchema(response,"GetPromotionsSchema.json");
    }
    @Test(description = "Validate that the ID value is the same as the ID value that was used in the Request")
    public void validateID(){
        GetPromotionsAPI promotion=new GetPromotionsAPI();
        LoginTest loginTest=new LoginTest();
        loginTest.testLogin();
        Response response= promotion.getPromotions(loginTest.accessToken);
        PromotionsResponseObject promotionsResponseObject= PromotionsMapper.readPromotionsObject(response);
      String responseID= promotionsResponseObject.getId().toString();
        Assert.assertEquals(responseID,"3");
    }
}
