import API_Objects.LoginResponseObject;
import Apis.LoginAPI;
import Common.Helper;
import Mapper.LoginMapper;
import io.restassured.response.Response;
import org.testng.annotations.Test;

public class LoginTest {


    String accessToken;


    @Test(description = "Validate JSON Schema and data types && Save the token value")
    public void testLogin(){
        LoginAPI login=new LoginAPI();
        Response response= login.postLogin("ammantesting@gmail.com","Test@1234");
//        response.prettyPrint();
        LoginResponseObject loginResponseObject=LoginMapper.readLoginObject(response);
         accessToken=loginResponseObject.getAccessToken().toString();
        //validateJSON
        Helper.validateJSONSchema(response,"LoginSchema.json");
    }

}
